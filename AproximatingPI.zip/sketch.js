let block1;
let block2;
let countHits = 0;
let countDiv;
let digits = 9;
const timeSteps = 10000000;

function setup() {
    createCanvas(windowWidth, 200);
    block1 = new Block(100, 20, 1, 0);
    const m2 = pow(100, digits-1);
    block2 = new Block(200, 150, m2, -5/timeSteps);
    countDiv = createDiv(countHits);
  }
  
  function draw() {
    background(200);

    for(let i = 0; i < timeSteps; i++) {
      if(block1.collide(block2)) {
        const v1 = block1.bounce(block2);
        const v2 = block2.bounce(block1);
        block1.v = v1;
        block2.v = v2;
        countHits++;
      }
      
      if(block1.hitWall()) {
        block1.reverse();
        countHits++;
      }

      block1.update();
      block2.update();
    }

    block1.show();
    block2.show();

    countDiv.html(countHits);
  }

class Block
{
    constructor(x, w, m, v) {
        this.x = x;
        this.y = height - w;
        this.w = w;
        this.m = m;
        this.v = v;
    }

    hitWall() {
      return (this.x <= 0);
    }

    reverse() {
      this.v *= -1;
    }

    bounce(other) {
      let sumM = this.m + other.m;
      let newV = (this.m - other.m) / sumM * this.v;
      newV += (2 * other.m  / sumM) * other.v;

      return newV;
    }

    collide(other) {
      return !(this.x + this.w < other.x || other.x + other.w < this.x);
    }

    update() {
      this.x += this.v;
    }

    show() {
        rect(this.x, this.y, this.w, this.w);
    }
}